import time

while True:
    time.sleep(1)
